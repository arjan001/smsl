<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 7/6/19
 * Time: 12:35 PM
 */
return [
    ['name' => 'setting.setting.index', 'display_name' => 'View settings', 'module' => 'Setting'],
    ['name' => 'setting.setting.edit', 'display_name' => 'Edit Settings', 'module' => 'Setting'],
];