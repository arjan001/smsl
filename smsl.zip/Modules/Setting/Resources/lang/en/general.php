<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 7/6/19
 * Time: 1:46 PM
 */
return [
    'setting' => 'Setting|Settings',
    'key' => 'Key|Keys',
    'value' => 'Value|Values',
    'general' => 'General',
    'system' => 'System',
    'update' => 'Update',
    'email' => 'Email|Emails',
    'sms' => 'SMS|SMSs',
    'other' => 'Other|Others',
    'organisation' => 'Organisation|Organisations'
];