<?php

return [
    'name' => 'Income'
];
