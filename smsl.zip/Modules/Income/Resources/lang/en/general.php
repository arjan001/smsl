<?php
return [
    'income' => 'Income',
    'type' => 'Type|Types',
    'amount' => 'Amount',
    'recurring' => 'Recurring',
    'recur_end_date' => 'Recur End Date',
    'recur_start_date' => 'Recur Start Date',
    'recur_type' => 'Recur Type',
    'day' => 'Day|Days',
    'year' => 'Year|Years',
    'month' => 'Month|Months',
    'week' => 'Week|Weeks',
    'recur_frequency' => 'Recur Frequency',
    'every' => 'Every',
];