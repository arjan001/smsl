<?php

return [
    'name' => 'Mpesa'
];
