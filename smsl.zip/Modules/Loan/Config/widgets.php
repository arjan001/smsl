<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 8/3/19
 * Time: 8:03 AM
 */
return [
    'LoanStatistics' => ["class" => 'Loan::LoanStatistics', "name" => "Loan Statistics","x"=>0,"y"=>0,"width"=>12,"height"=>2],
    'LoanStatusOverview' => ["class" => 'Loan::LoanStatusOverview', "name" => "Loan Status Overview","x"=>0,"y"=>2,"width"=>4,"height"=>4],
    'LoanCollectionOverview' => ["class" => 'Loan::LoanCollectionOverview', "name" => "Loan Collection Overview","x"=>4,"y"=>2,"width"=>8,"height"=>6]
];