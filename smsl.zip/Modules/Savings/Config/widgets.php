<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 8/3/19
 * Time: 8:03 AM
 */
return [
    //'SavingsStatistics' => ["class" => 'Savings::SavingsStatistics', "name" => "Loan Statistics", "x" => 0, "y" => 0, "width" => 12, "height" => 2],
    'SavingsBalanceOverview' => ["class" => 'Savings::SavingsBalanceOverview', "name" => "Savings Balance Overview", "x" => 4, "y" => 2, "width" => 4, "height" => 4]
];